umask 0022
export CLASSPATH=.:junit.jar:PerfAnal.jar

