# properly set the CMT variables

CMTBIN=`uname`-`uname -m | sed -e 's# ##g'`; export CMTBIN
export CMTLIB=${CMTBIN}

echo CMTBIN set to $CMTBIN

export CMTROOT=${HOME}/cmt-dev/CMT/v1r18p20050501
export CMTHOME=${CMTROOT}
