#include "G.h"

void G::print ()
{
        cout<<"Hello from G"<<endl;
}
