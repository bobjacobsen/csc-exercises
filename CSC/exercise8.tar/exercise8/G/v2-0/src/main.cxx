#include "A.h"
#include "B.h"
#include "C.h"
#include "D.h"
#include "E.h"
#include "F.h"
#include "G.h"

int main()
{
    G g;
    
    g.print ();

    return 0;
}
