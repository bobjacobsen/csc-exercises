#include "F.h"

void F::print ()
{
        cout<<"Hello from F"<<endl;
}
