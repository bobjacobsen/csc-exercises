#include <iostream>

using namespace std;

class F
{
    public:
        F() {}
        ~F()  {}
        void print ();
};
