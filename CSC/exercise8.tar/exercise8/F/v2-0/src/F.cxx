#include "F.h"
#include "E.h"

void F::print ()
{
        E e;
        e.print();
        cout<<"Hello from F"<<endl;
}
