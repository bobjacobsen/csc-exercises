#include "C.h"

void C::print ()
{
        cout<<"Hello from C"<<endl;
}
