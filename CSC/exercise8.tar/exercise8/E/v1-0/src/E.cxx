#include "E.h"

void E::print ()
{
        cout<<"Hello from E"<<endl;
}
