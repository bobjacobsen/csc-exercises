# echo "Setting E v2-0 in /Users/jake/CSC/exercise10"

if test "${CMTROOT}" = ""; then
  CMTROOT=/Users/jake/cmt-dev/CMT/v1r18p20050501; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh

tempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then tempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt setup -sh -pack=E -version=v2-0 -path=/Users/jake/CSC/exercise10  -no_cleanup $* >${tempfile}; . ${tempfile}
/bin/rm -f ${tempfile}

