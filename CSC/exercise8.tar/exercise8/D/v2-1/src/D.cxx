#include "D.h"
#include "C.h"

void D::print ()
{
        C c;
        c.print();
        cout<<"Hello from D"<<endl;
}
