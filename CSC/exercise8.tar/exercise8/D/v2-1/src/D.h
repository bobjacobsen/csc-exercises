#include <iostream>

using namespace std;

class D
{
    public:
        D() {}
        ~D()  {}
        void print ();
};
