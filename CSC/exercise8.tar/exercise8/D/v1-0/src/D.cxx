#include "D.h"

void D::print ()
{
        cout<<"Helo from D"<<endl;
}
