#include "D.h"

void D::print ()
{
        cout<<"Hello from D"<<endl;
}
