//////////////////////////////////////////////////
// author: vincent garonne                      //
// date:   4/5/2005                             //
// description: hello world description file    //
//////////////////////////////////////////////////

#ifndef __HELLO_WORLD__
#define __HELLO_WORLD__

class hello
{
    public:
        // constructor
        hello  () {}
        
        // desctructor
        ~hello (){}

        // function example
        void print ();
};
#endif // __HELLO_WORLD__
