//////////////////////////////////////////////////
// author: vincent garonne                      //
// date:   4/5/2005                             //
// description: hello world body                //
//////////////////////////////////////////////////

#include "hello.h"

int main ()
{     
     hello object;
     object.print();
     return 0;
}
