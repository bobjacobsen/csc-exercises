#include "A.h"

void A::print ()
{
        cout<<"Hello from A"<<endl;
}
