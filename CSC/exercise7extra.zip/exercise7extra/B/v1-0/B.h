#include <iostream>

using namespace std;

class B
{
    public:
        B() {}
        ~B()  {}
        void print ();
};
