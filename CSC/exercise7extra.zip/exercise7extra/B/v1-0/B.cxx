#include "B.h"

void B::print ()
{
        cout<<"Hello from B"<<endl;
}
