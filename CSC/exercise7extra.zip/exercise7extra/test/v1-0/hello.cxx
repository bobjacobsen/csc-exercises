//////////////////////////////////////////////////
// author: vincent garonne                      //
// date:   4/5/2005                             //
// description: hello world body                //
//////////////////////////////////////////////////

using namespace std;
#include <iostream>

#include "hello.h"

void hello::print ()
{
        cout<<"Hello world !!!"<<endl;
}

