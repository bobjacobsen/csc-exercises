#include "G.h"
#include "F.h"

void G::print ()
{
        F f;
        f.print();
        cout<<"Hello from G"<<endl;
}
