#include <iostream>

using namespace std;

class E
{
    public:
        E() {}
        ~E()  {}
        void print ();
};
