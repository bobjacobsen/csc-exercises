#include "A.h"
#include "B.h"

int main()
{
    A a;
    B b;
    
    a.print ();
    b.print ();

    return 0;
}
