#include <iostream>

using namespace std;

class A
{
    public:
        A() {}
        ~A()  {}
        void print ();
};
