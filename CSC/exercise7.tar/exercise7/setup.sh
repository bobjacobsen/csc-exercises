source setvar.sh

export CMTPATH=`pwd`
source ${CMTHOME}/mgr/setup.sh

export   LD_LIBRARY_PATH=${PWD}/A/V1/${CMTLIB}:${PWD}/B/v1/${CMTLIB}
export DYLD_LIBRARY_PATH=${PWD}/A/V1/${CMTLIB}:${PWD}/B/v1/${CMTLIB}

chmod o+r ~
chmod o+x ~

