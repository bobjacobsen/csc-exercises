# properly set the CMT variables to one of two cases

CMTBIN=`uname`-`uname -m | sed -e 's# ##g'`; export CMTBIN
export CMTLIB=Darwin

if test "${CMTBIN}" != "Darwin-PowerMacintosh" ; then
  export CMTBIN=Linux-x86_64
  export CMTLIB=Linux-x86_64
fi

echo CMTBIN set to $CMTBIN

export CMTROOT=${HOME}/cmt-dev/CMT/v1r18p20050501
export CMTHOME=${CMTROOT}
