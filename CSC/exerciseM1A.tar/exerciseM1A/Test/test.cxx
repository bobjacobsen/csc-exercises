#include <iostream>
#include "hello.h"
int main() { 
    Hello().Print();
    return 0;
}
