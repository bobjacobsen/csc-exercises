#include "hello.h"
#include <iostream>
using namespace std;

void Hello::Print() {
    cout<<"Hello, World!"<<endl; 
}