umask 0022
chmod 755 .

