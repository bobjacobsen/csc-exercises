#include "Base.h"

char* Base::other() {
    return " (from Base v1-0) ";
}
