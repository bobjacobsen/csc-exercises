#include <iostream>

using namespace std;

class Base
{
    public:
        Base() {}
        ~Base()  {}
        static void log (char* message) { 
            cout<<"Log: "<<message
                <<other()<<endl; 
        }
        static char* other();
};
