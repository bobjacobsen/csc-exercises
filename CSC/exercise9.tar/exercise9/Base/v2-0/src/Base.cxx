#include "Base.h"

char* Base::other() {
    return " (from Base v2-0) ";
}
