#include <iostream>

using namespace std;

class Base
{
    public:
        Base() {}
        ~Base()  {}
        static void log (char* message, int severity) { 
            cout<<"Log: "<<message
                <<" at severity "<<severity
                <<other()<<endl;
        }
        static char* other();
};
