#include <iostream>

using namespace std;

class User1
{
    public:
        User1() {}
        ~User1()  {}
        void print ();
};
