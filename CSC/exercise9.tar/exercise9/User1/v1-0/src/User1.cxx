#include "User1.h"
#include "Base.h"

void User1::print ()
{
        cout<<"User1 invokes the logging"<<endl;
        Base::log("logged by User1");
}
