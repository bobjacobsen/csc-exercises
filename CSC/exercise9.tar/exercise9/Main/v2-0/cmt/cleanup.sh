if test "${CMTROOT}" = ""; then
  CMTROOT=/Users/jake/cmt-dev/CMT/v1r18p20050501; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
tempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then tempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt cleanup -sh -pack=G -version=v2-0 -path=/Users/jake/CSC/exercise10 $* >${tempfile}; . ${tempfile}
/bin/rm -f ${tempfile}

