#include "User1.h"
#include "User2.h"

int main()
{
    User1 u1;
    User2 u2;

    u1.print ();
    u2.print ();

    return 0;
}
