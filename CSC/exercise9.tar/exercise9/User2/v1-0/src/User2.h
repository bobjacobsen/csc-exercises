#include <iostream>

using namespace std;

class User2
{
    public:
        User2() {}
        ~User2()  {}
        void print ();
};
