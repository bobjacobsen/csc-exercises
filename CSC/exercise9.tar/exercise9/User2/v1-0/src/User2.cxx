#include "User2.h"
#include "Base.h"

void User2::print ()
{
        cout<<"User2 invokes the logging"<<endl;
        Base::log("logged by User2");
}
