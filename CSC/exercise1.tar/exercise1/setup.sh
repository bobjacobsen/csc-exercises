umask 0022
chmod 755 .
export CLASSPATH=.:junit.jar:PerfAnal.jar

