#include <iostream>

using namespace std;

class C
{
    public:
        C() {}
        ~C()  {}
        void print ();
};
