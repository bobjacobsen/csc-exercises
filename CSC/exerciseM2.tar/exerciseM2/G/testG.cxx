#include "A.h"
#include "B.h"
#include "C.h"
#include "D.h"
#include "E.h"
#include "F.h"
#include "G.h"

int main()
{
    A a;
    B b;
    C c;
    D d;
    E e;
    F f;
    G g;
    
    a.print ();
    b.print ();
    c.print ();
    d.print ();
    e.print ();
    f.print ();
    g.print ();

    return 0;
}
