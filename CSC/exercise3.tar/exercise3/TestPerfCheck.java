
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.framework.Assert;

public class TestPerfCheck extends TestCase  {
    
    // define a series of tests for the "sieve" algorithm
    
    public void testSieve2to3() {
	// a first test, to check machinery is working
	    int r = PerfCheck.sieveCheck(2,3);
	    // finds 2, not 3
	    Assert.assertEquals("from 2 through 3", 1, r);
    }
    
    public void testSieve2to4() {
	// a first test, to check machinery is working
	    int r = PerfCheck.sieveCheck(2,4);
	    // finds 2, 3 before checking 4
	    Assert.assertEquals("from 2 through 4", 2, r);
    }
    
    public void testSieve2to10() {
	// a first test, to check machinery is working
	    int r = PerfCheck.sieveCheck(2,10);
	    // finds 2, 3 before checking 4
	    Assert.assertEquals("from 2 through 10", 4, r);
    }
    
    // define a series of tests for the "simple" algorithm

    public void testSimple2to3() {
	// a first test, to check machinery is working
	    int r = PerfCheck.simpleCheck(2,3);
	    // finds 2, not 3
	    Assert.assertEquals("from 2 through 3", 1, r);
    }
    
    public void testSimple2to4() {
	// a first test, to check machinery is working
	    int r = PerfCheck.simpleCheck(2,4);
	    // finds 2, 3 before checking 4
	    Assert.assertEquals("from 2 through 4", 2, r);
    }
    
    public void testSimple2to10() {
	// a first test, to check machinery is working
	    int r = PerfCheck.simpleCheck(2,10);
	    // finds 2, 3 before checking 4
	    Assert.assertEquals("from 2 through 10", 4, r);
    }
    
    
    
    // from here on is testing infrastructure, no mods needed
    
    public TestPerfCheck(String s) {
	super(s);
    }
    
    // Main entry point
    static public void main(String[] args) { 
	String[] testCaseName = {TestPerfCheck.class.getName()};
	// initialize junit as either GUI or command line
	if ( args.length == 0 || args[0]==null) {
	    System.out.println("no optional arguments, no GUI");
	    junit.textui.TestRunner.main(testCaseName);
	}
	else {
	    System.out.println("argument provided, use GUI");
	    junit.swingui.TestRunner.main(testCaseName);
	}
    }
    
    // define test suite
    public static Test suite() {
	// all tests from here down in heirarchy
	TestSuite suite = new TestSuite(TestPerfCheck.class);
	return suite;
    }
    
}
