 
import java.io.IOException;

public class PerfCheck {
    
    /**
     * Count number of prime numbers in a range using 
     * factor checking of each number
     */
    static public int simpleCheck(int start, int end) {
        int count = 0;
        for (int test = start; test<end; test++) {
            if (checkOne(test)) count++;
        }
        return count;
    }
    
    /**
     * Check whether a single integer is prime via factor checking
     */
    static boolean checkOne(int test) {
        for (int factor = 2; 
             factor < (int) Math.sqrt(test); 
             factor++) {
             
          if (test % factor == 0) 
                return false;
        }
        return true;
    }
       
    /**
     * Count number of prime numbers in a range using the 
     * Sieve of Erathsones
     */
    static int sieveCheck(int start, int end) {
    
        // create a list of possible prime numbers
        boolean[] check = new boolean[end];
        for (int i = 0; i<end; i++) check[i] = true;
        
        // mark off array if the number has a factor, hence can't be prime.
        for (int factor = 2; factor < (int) Math.sqrt(end); factor++) {
            int index = 2*factor;
            while (index < end) {
                check[index] = false;
                index = index+factor;
            }
        }
        
        // finally, count the result
        int result = 0;
        for (int i = start; i<end; i++)
            if (check[i]) result++;
        return result;
    }      

    /**
     * Main routine, for running as program
     */
    public static void main(String[] args) {
        
        if (null != 
            System.getProperty("WaitForProfiler")) {
            System.out.println("Start your profiler,  then press any key to begin...");
            try {
                System.in.read();
            }
            catch (IOException ioe) {
            }
        }
        
        
        long beginTime, endTime;
        int result;  
        
        int start   =  900000;
        int end     = 1000000;
        int REPEATS = 100;

        // to get more ticks for the analysis, we run a bunch of times
        for (int i=0; i<REPEATS; i++) {

	    // now run each one to capture a time
	    beginTime = System.currentTimeMillis();
	    result = simpleCheck(start, end);
	    endTime = System.currentTimeMillis();
	    
	    System.out.println("simpleCheck took "+(endTime-beginTime)+" msec and found "+result);
	    
	    beginTime = System.currentTimeMillis();
	    result = sieveCheck(start, end);
	    endTime = System.currentTimeMillis();
	    
	    System.out.println(" sieveCheck took "+(endTime-beginTime)+" msec and found "+result);
	}
        
    }
} 
