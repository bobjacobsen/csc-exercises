umask 0022
export MALLOC_CHECK_=0
cp valgrindrc ~/.valgrindrc

