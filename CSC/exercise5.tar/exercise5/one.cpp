#include <iostream>
using namespace std;
int main()
{
  
  int val;
  
  cout << "Hello World!" << endl;   

  val = 1;
  
  cout << "Value is " << val << endl;
  
  cout << "Done" << endl;

}
