#include <iostream>
using namespace std;
int main()
{
  
  int *ptr;
  
  cout << "Hello World!" << endl;   

  *ptr = 2;
  
  cout << "Value is " << *ptr << endl;
  
  cout << "Done" << endl;

}
