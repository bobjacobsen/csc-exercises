# properly set the CMT variables to one of two cases

CMTBIN=`uname`-`uname -m | sed -e 's# ##g'`; export CMTBIN
export CMTLIB=Darwin

if test "${CMTBIN}" != "Darwin-PowerMacintosh" ; then
  export CMTBIN=Linux-i686
  export CMTLIB=Linux-i686
fi

echo CMTBIN set to $CMTBIN

export CMTHOME=/home/jake/cmt-dev/CMT/v1r18p20050501
