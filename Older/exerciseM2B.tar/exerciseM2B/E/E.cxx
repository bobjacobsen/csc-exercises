#include "E.h"
#include "D.h"

void E::print ()
{
        D d;
        d.print();
        cout<<"Hello from E"<<endl;
}
