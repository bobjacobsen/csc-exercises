#include <iostream>

using namespace std;

class D2
{
    public:
        D2() {}
        ~D2()  {}
        void print ();
};
