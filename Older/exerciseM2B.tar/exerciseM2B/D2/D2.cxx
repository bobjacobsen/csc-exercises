#include "D2.h"

void D2::print ()
{
        cout<<"Hello from D via D2"<<endl;
}
