#include "G.h"

int main()
{
    G g;
    
    g.print ();

    return 0;
}
