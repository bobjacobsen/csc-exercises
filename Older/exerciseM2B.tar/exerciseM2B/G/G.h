#include <iostream>

using namespace std;

class G
{
    public:
        G() {}
        ~G()  {}
        void print ();
};
