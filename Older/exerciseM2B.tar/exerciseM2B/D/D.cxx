#include "D.h"
#include "D2.h"
#include "C.h"

void D::print ()
{
        C c;
        c.print();
        D2 d;
        d.print();
}
